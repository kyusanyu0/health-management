import React from 'react'

export const Sidebar = () => {
  return (
    <div>Sidebar</div>
  )
}
